from json import load as jsnLoad
from stUtil import rndrCode
from typing import List, Dict, Any
def 束資源(filename: str) -> List[Dict[str, Any]]:
  """Return an array of the Bundle's entry's "resource" elements."""
  #LOGGER.info(f"Reading {filename}")
  filepath = filename
  with open(str(filepath), encoding="utf-8") as handle:
    parsed = jsnLoad(handle)
    rndrCode(['parsed', parsed])
    if "resourceType" not in parsed:
        raise Exception(f'Expecting "resourceType" to be present, but is not in {filepath}')
    if "Bundle" != parsed["resourceType"]:
        raise Exception('Can only process "Bundle" resources')
    if "entry" not in parsed:
        raise Exception(f"There are no entries in the Bundle at {filepath}")
    return [e["resource"] for e in parsed["entry"]]
