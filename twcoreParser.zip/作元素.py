from streamlit import set_page_config as pageConfig, sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect, tabs as stTAB, info as stInfo, write as stWrite
from streamlit import button, toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache,
from profileUtil import 找bckBone, 聚集
from stUtil import rndrCode
from pandas import DataFrame
from stringcase import camelcase
from re import compile as 編譯, search, IGNORECASE

#  todos:
#  title="male | female | other | unknown",
#  enum_values=["male", "female", "other", "unknown"],
#  enum_reference_types=["Organization", "Practitioner", "PractitionerRole"],
#  enum_values=["replaced-by", "replaces", "refer", "seealso"],
#  enum_reference_types=["Patient", "RelatedPerson"],
#  enum_reference_types=["Organization", "Practitioner", "PractitionerRole"],
#  enum_reference_types=["Organization"],
#  element_property=True,
#  element_required=True,
#1. 順序錯序的情形
#1. 將所有的識別訊息 存起來
#1. root_validator
#1. must_support?

pageConfig(page_title='作資源', layout='wide', initial_sidebar_state='expanded')

MENU, 表單=[], ['資框', '資源', '普法資源', '特普']	#頭包, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
首字=編譯('\w+')
def bone字典(普欄):
  背骨元素=找bckBone(普欄)
  背骨長=len(背骨元素)
  骨典=dict(zip(背骨元素, range(背骨長)))
  return 骨典
def rtrvRSRC(ele, 頭):
  return ele.replace(f'{頭}.', '')
def mkTMPL(row):
  rndrCode(row)
  return [ele for ele in row]
def mkRSRC(row, 火型):
  元素=row.split('|')
  頭=元素[0]
  新元=[ele.replace(f'{頭}.', '') for ele in 元素]  #
  素, newEle={}, []
  for ele in 新元:
    Pttrn=首字.match(ele).group(0)
    if not 素.get(Pttrn):
      素[Pttrn]=True
      newEle.append(Pttrn)
  newEle=newEle[1:]
  newEle.insert(0, 頭)
  新素元=[f'{頭}.{ele}' for ele in newEle]
  #新素元
  #新元=set(新元).add(頭)
  #新元.insert(0, 頭)
  return newEle #新素元,
def mkRSRCold(欄位, 火型):
  with open('資源tmpl.py') as tmpl:
    範本=tmpl.read()
  with open('主元素.py') as mainEle:
    主元素=mainEle.read()
  新範本=''
  rndrCode(['欄位, 火型', 欄位, 火型])
  for 欄 in 欄位:
    #rndrCode([欄])
    if 欄.istitle():
      新範本+=主元素.replace('{主元素}', 欄)
    else:
      新範本+=範本.replace('{tmpl元素}', 欄)
  return 新範本
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[3]:
  #特普 頭包
  for k, v in session_state.items():
    if k.find('徑')!=-1:
      rndrCode([k, session_state[k]])
      #rndrCode(['徑', k, v])

elif menu==MENU[2]:
  #新元素=session_state['新元素']#=聚合['新元'].values
  #newELE=新元素.tolist()#apply(mkTMPL)#['value']
  #rndrCode(newELE)
  特普=session_state['特普']
  for ele in session_state[特普]:
    rndrCode(ele)
  #dfProf=DataFrame(session_state[特普])
  #dfProf
  #rndrCode()
  #for ele in session_state[特普]: rndrCode([ele])
  with open('資源tmpl.py') as tmpl:
    範本=tmpl.read()
  with open('主元素.py') as mainEle:
    主元素=mainEle.read()
  rndrCode(主元素)
  rndrCode(範本)
  骨=編譯('backbone', IGNORECASE)
  with open('匯入.py') as fin:
    全範本=fin.read()
  for 束 in session_state[特普]:
    #rndrCode([束])
    新範本, 全型='', set()
    for ndx, ele in enumerate(束):
      if not ndx:
        if type(ele) is not tuple:
        #元素=list(ele.keys())[0]
          for 頭, 主型 in ele.items():pass
          全型.add(主型)
          #if ele.find('.')!=-1:
          #主, 從=ele.split('.')
          #主從=主+從.capitalize()
          主型='BackboneElement' if 骨.search(主型) else 'DomainResource'
          新範本+=主元素.replace('{主元素}', 頭).replace('{主型}', 主型)
        else:
          for ndx, 素 in enumerate(ele):
            if not ndx:
              for 頭, 型 in 素.items():pass
              k=k.replace(f'{頭}.', '')
              識, 旁=頭.split('.')
              旁=旁.capitalize()
              新範本+=主元素.replace('{主元素}', f'{識}{旁}').replace('{主型}', 型)
            else:
              for 頭, 型 in 素.items():pass
              #全型.add(型)
              k=k.replace(f'{頭}.', '')
              新範本+=範本.replace('{tmpl元素}', k).replace('{型}', 型).replace('[x]', '')  #元素
            全型.add(型)
      else:
        if type(ele) is tuple:
          #rndrCode(['tuple', ele])
          for k, v in ele[0].items():pass
          全型.add(v)
          k=k.replace(f'{頭}.', '')
          新範本+=範本.replace('{tmpl元素}', k).replace('{型}', v).replace('[x]', '')  #元素
        else:
          for k, v in ele.items():pass
          全型.add(v)
          k=k.replace(f'{頭}.', '')
          新範本+=範本.replace('{tmpl元素}', k).replace('{型}',  v).replace('[x]', '')
    rndrCode([頭, 新範本])
    #新全型=map(lambda x:x.capitalize()+"Type", 全型)
    全範本+=新範本

    if 頭.find('.')!=-1:
      rndrCode([頭])
      識, 旁=頭.split('.')[:2]
      旁=旁.capitalize()
      with open(f'{識}{旁}.raw', 'w') as fout:
        fout.write(新範本)
    else:
      with open(f'{頭}.raw', 'w') as fout:
        fout.write(新範本)
  普識型=特普.split('-')[0].lower()
  rndrCode(['普識型', 普識型])
  全型.remove('BackboneElement')
  全範本=全範本.replace('{全型}', ', '.join(全型))
  with open(f'{普識型}.raw', 'w') as fout:
    fout.write(全範本)
    #rndrCode(['新範本', 新範本])
  #tmplELE=map(mkTMPL, newELE)
  #rndrCode(tmplELE)
elif menu==MENU[1]:
  普欄=session_state['普欄']
  #try:
  聚合 =session_state['聚合']#=普欄.groupby('堆疊')['Id'].agg('|'.join).reset_index()
  #except:
  #  聚合=session_state['聚合']=普欄.groupby('堆疊')['Id'].agg('|'.join).reset_index()
  火型=聚合['Type(s)']
  火型
  #rndrCode(['火型', 火型])
  聚合['新元']=聚合['Id'].apply(mkRSRC, args=(火型, ))
  #新素元=[f'{頭}.{ele}' for ele in newEle]
  聚合['新元']
  #聚合['Type(s)']
  #新元素=聚合['新元'].values  #session_state['新元素']=
  #新元素#[]
elif menu==MENU[0]: #資框
  #todos:enum_type, validator, Dict, util, 抽象
  from fhir規格 import 火規格#, 結構定義元素
  #結定元=結構定義元素()
  try:
    普法=session_state['普法']
  except:
    火=火規格('/home/josh/twcore/CSV/all-profiles.csv')
    普法=session_state['普法']=火.fhirDF
  try:
    普法欄=session_state['普法欄']
  except:
    普法欄=session_state['普法欄']=普法.columns
  try:
    特普法=session_state['特普法']#=普法['Profile'].unique()
  except:
    特普法=session_state['特普法']=普法['Profile'].unique()
  frstTAB, scndTAB, thrdTAB=stTAB(['1stTAB', '2ndTAB', '3rdTAB'])
  with sidebar:
    #欄位=stRadio('欄位', 普法.columns, horizontal=True, index=0)
    rndrCode(['普法欄全數', len(普法欄)])
    普欄位=multiselect('普法欄位', 普法欄)
    #單普=stRadio('單普', 單普法, horizontal=True, index=54)
  with frstTAB:
    特普=session_state['特普']=stRadio('單普', 特普法, horizontal=True, index=54)
  with scndTAB:
    #with leftPane:
      #rndrCode(cntxt)
    #with rightPane:
    if 特普:
      try:
        普欄=session_state['普欄']
      except:
        普欄=session_state['普欄']=普法[普法['Profile']==特普]
      #普欄=session_state['普欄']
      if 普欄位:
        普欄[普欄位]#普欄[]
  #{'Patient': 0, 'Patient.contact': 1, 'Patient.communication': 2, 'Patient.link': 3}
  def 找徑(徑):
    #rndrCode(['徑', 徑])  #[f'徑{徑頭}', session_state[f'徑{徑頭}']]
    徑長=len(徑)
    if 徑長==2:
      頭, 尾=徑#[0], 徑[1]
      徑頭=f'徑{頭}'
      if 徑尾:=session_state.get(徑頭):
        徑尾.add(尾)
        session_state[徑頭]=徑尾
      else:
        session_state[徑頭]={尾}
      return session_state[徑頭]
      #return {'徑'+頭:{尾}}
    elif 徑長>2:
      徑頭, 徑尾=徑[0], 徑[1:]
      #rndrCode([f'徑{徑頭}', session_state.get(f'徑{徑頭}')])
      徑徑頭=f'徑{徑頭}'
      if 徑徑尾:=session_state.get(徑徑頭):
        #徑徑尾.add()
        rndrCode(['徑徑頭', 徑徑頭, '徑徑尾', 徑徑尾, '徑尾', 徑尾])
        徑徑尾.update(找徑(徑尾))
        #session_state[徑徑頭]=找徑(徑尾)#徑徑尾
        #徑徑頭.update({徑頭:找徑(徑尾)})
        #session_state[f'徑{徑頭}']=徑徑尾
      else:
        session_state[徑徑頭]=找徑(徑尾)#session_state[f'徑{徑尾[0]}']#set(徑尾)
      return session_state[徑徑頭]
      #if len(徑尾)==1: return None
      #else: return 徑尾
    #else: # 徑長==1:
    #  #rndrCode(['徑', 徑])
    #  頭=徑[0]
    #  session_state[f'徑{頭}']=None#set()
    #else:
    #  頭, 尾=徑[0], 徑[1]
    #  session_state[f'徑{頭}']=[尾]#set()
      #return 徑[0]
  def rtrv徑(徑):
    徑長=len(徑)
    if 徑長==2:
      頭, 尾=徑
      徑頭, 徑尾=f'徑{頭}', f'徑{尾}'
      if 尾徑:=session_state.get(徑頭):
        rndrCode(['尾徑=', 尾徑])
        尾徑.append(徑尾)
        session_state[徑頭]=尾徑
      else:
        session_state[徑頭]=[徑尾]
      #return {徑頭:徑尾}
    elif 徑長>2:
      頭, 尾=徑[0], 徑[1:]
      徑頭=f'徑{頭}'
      if 徑尾:=session_state.get(徑頭):
        rndrCode(['徑長>2', 徑, '徑尾=', 徑尾, '尾=', 尾])
        #rtrv徑(尾)
        #徑尾.add()
        #session_state[徑頭]=頭
        #rndrCode(['rtrv=', rslt, '頭=', 頭, '尾=', 尾])
        #session_state[徑頭]=rslt
        #頭.update(rslt)
      #else:
      rtrv徑(尾)  #pass
        #session_state[徑頭]=
    else:
      徑頭=f'徑{徑[0]}'
      session_state[徑頭]=set()

  def rtrv兩欄(*args):  #識別, 型, 識模, 型模
    (識別, 型別), 識模, 骨模, 型模, 徑模, 特普=args
    #session_state['計數']+=1
    if 識徵:=識模.search(識別): 識=識徵.group()
    if 骨徵:=骨模.search(型別): 骨=骨徵.group()
    else: 骨=None
    if 型徵:=型模.search(型別): 型=型徵.group()
    徑=徑模.findall(識別)
    #rndrCode(['徑=', 徑])
    徑長=len(徑)
    #if 徑長==2:
    def 徑徑(徑):
      頭, 尾=徑[0], 徑[1:]
      徑長=len(徑)
      徑頭, 徑尾=f'徑{頭}', f'徑{尾}'
      if
      if 尾尾:=session_state.get(徑頭):
        尾尾.append(徑尾)
        #rndrCode(['尾尾', 尾尾])
        #尾尾=[set(尾尾)]
        session_state[徑頭]=[{徑頭:尾尾}]
      else:
        session_state[徑頭]=[徑尾]
    徑徑(徑)
    if not 骨: 型=型.capitalize()+'Type'
    #型=型.capitalize()+'Type' if not 骨 else 型.capitalize()
    #if 型=='Backboneelement': 型='BackboneElement'
    #型=camelcase(型)
    if session_state.get(識): session_state[識]+=({識別:型}, ) #有找到包
    else: session_state[識]=({識別:型}, )    # assign識包
    if 骨:
      if session_state.get('頭包'):  #處理 1. 設定頭
        session_state[特普].append(session_state['頭包'])
      if session_state.get(f'徑{特普}'):
        session_state[f'徑{特普}'].append(session_state['徑包'])
        #rndrCode(['頭包', session_state['頭包']] )
      session_state['頭包']=[]  #2. 清空
      session_state['徑包']=[]  #2. 清空
        #session_state['骨數']+=1
      #頭包=session_state['頭包']=[]   #只會執行一次
      session_state['頭包'].extend(session_state[識])
      session_state['徑包'].extend(session_state[識])
        #session_state['計數']=0
      #頭包.append(session_state[識])
      #頭包.append(session_state[識])
      #頭識=session_state['頭']={識:''}
    else:
      if len(session_state[識])>session_state['多識']:  #處理多識情形
        #session_state['頭包']=session_state['頭包'][:session_state['計數']-len(session_state[識])].extend(session_state[識])
        #if session_state['多識']:
        #  pass
        #  session_state['頭包'].append(session_state[識][-1])
        #else:
        session_state['頭包']=session_state['頭包'][:-1]
        session_state['頭包'].append(session_state[識])
      else:
        session_state['頭包'].extend(session_state[識]) #單一識
    session_state['多識']=len(session_state[識])
      #頭識={識:''}
    #頭包=session_state['頭包']#=[]
    #頭包.append(session_state[識])
    return str(徑)#, str(識), str(骨), str(型), str(session_state[識]), str(session_state['頭包'])#str(徑),
    #普欄.loc[普欄['Id']==ele].index
  sssnInfo=''
  for k, v in session_state.items():
    if k.find('徑')!=-1:
      sssnInfo+='|'.join([k, str(v)])+', '
  rndrCode(['鍵值', k, sssnInfo])
  def initSSSN():
    鍵值=''
    for k,v in session_state.items():#['徑{徑頭}', 'Patient.telecom', 'Patient.link', 'Patient.modifierExtension', 'Patient.address', 'Patient-twcore', 'Patient', 'Patient.managingOrganization', 'Patient.birthDate', 'Patient.active', 'Patient.id', 'Patient.multipleBirth', 'Patient.name', 'Patient.language', 'Patient.contact', 'Patient.extension', 'Patient.text', 'Patient.deceased', 'Patient.generalPractitioner', 'Patient.meta', 'Patient.maritalStatus', 'Patient.photo', 'Patient.identifier', 'Patient.communication', 'Patient.contained', 'Patient.gender', 'Patient.implicitRules', "徑['meta']", '徑contained', '徑code', '徑managingOrganization', '徑usual', "徑['version']", '徑nationality', '徑userSelected', "徑['residentNumber']", '徑idCardNumber', '徑use', '徑implicitRules', "徑['age']", "徑['communication']", '徑meta', "徑['text']", '徑deceased', "徑['id']", '徑link', "徑['official']", '普欄', "徑['display']", '徑generalPractitioner', "徑['birthDate']", '徑identifier', "徑['given']", '徑given', "徑['rank']", '徑system', '徑other', '特普', '徑id', "徑['userSelected']", '徑official', "徑['photo']", '徑prefix', "徑['anonymous']", '徑suffix', '徑version', '多識', '徑coding', '徑communication', '徑age', '徑temp', "徑['coding']", '徑type', "徑['identifier']", '普法欄', '徑photo', '徑rank', '徑birthDate', "徑['multipleBirth']", "徑['organization']", "徑['contained']", '初始', "徑['medicalRecord']", "徑['relationship']", "徑['deceased']", '徑assigner', "徑['identifier-suffix']", '徑Patient', '徑preferred', "徑['value']", "徑['name']", '徑modifierExtension', "徑['family']", "徑['contact']", '徑multipleBirth', '徑name', '徑active', '徑language', "徑['maritalStatus']", '徑telecom', '頭包', "徑['type']", '徑extension', "徑['period']", '普法', '徑contact', "徑['Patient']", '徑anonymous', "徑['managingOrganization']", "徑['idCardNumber']", "徑['preferred']", "徑['other']", "徑['telecom']", '特普法', '聚合', '徑medicalRecord', "徑['nationality']", '徑address', '徑residentNumber', "徑['code']", "徑['prefix']", '徑relationship', "徑['link']", '徑text', "徑['extension']", '徑period', '徑gender', '徑display', "徑['usual']", "徑['generalPractitioner']", "徑['language']", "徑['gender']", "徑['address']", '徑family', '徑maritalStatus', '徑organization', "徑['system']", "徑['assigner']", "徑['active']", '徑value', "徑['suffix']", "徑['implicitRules']", "徑['modifierExtension']", "徑['use']", "徑['temp']", '徑identifier-suffix', '徑passportNumber', "徑['passportNumber']"]:  #, '頭包'
      if k.find('徑')!=-1:
        鍵值+=k
        try: del session_state[k]
        except: pass
    rndrCode(['鍵值=', 鍵值])
      #session_state['計數']=0 #共有4個骨元素 Patient, Contact, Patient.Communication, Patient.Link
  初始=button('初始化', '初始')
  if 初始: initSSSN()
  session_state['頭包']=[]  #2. 清空
  with thrdTAB:
    session_state[特普]=[]
    #rndrCode(['特普', session_state[特普]])
    leftPane, rightPane=stCLMN([2, 9])
    #普欄[['Id', 'Type(s)']]
    with leftPane:
      骨典=bone字典(普欄)
      #rndrCode([骨典])
      識模, 骨模, 型模, 徑模=編譯('(\w+\.?\w+)'),   編譯('null|BackboneElement'), 編譯('\w+'), 編譯('\w+-?\w+')
      普欄['堆疊']=普欄[['Id', 'Type(s)']].apply(rtrv兩欄, args=(識模, 骨模, 型模, 徑模, 特普), axis=1)#(x, y) , )    #'Type(s)'.str.match('null|BackboneElement'
      session_state[特普].append(session_state['頭包'])
    普欄[['Id', 'Type(s)', '堆疊']]
    rndrCode(session_state[特普])
    #rndrCode(['特普', session_state[特普]])
    #普欄[['Id', 'Type(s)', '堆疊']]
      #rndrCode(['識型', session_state[特普]])
      #普欄['堆疊']=普欄['Id', 'Type(s)'].apply(聚集, args=(骨素型,))    #'Type(s)'.str.match('null|BackboneElement'
    #普欄
    #普欄['找到']=普欄.groupby(['Id']).where(普欄['Type(s)'].str.match('BackboneElement|null'))
    with rightPane:
      #聚集Id=普欄.groupby(['堆疊']).普欄['Id'].agg(''.join)
      try:
        聚合 =session_state['聚合']
      except: 聚合=session_state['聚合']=普欄.groupby('堆疊')[['Id', 'Type(s)']].agg('|'.join).reset_index()
      火型=聚合['Type(s)']
      聚合['新元']=聚合['Id'].apply(mkRSRC, args=(火型, ))
      #新素元, 新素元, 新素元
      #聚合['新元'].apply(rtrv指標)#.values
      #聚合['新元'].apply(rtrv指標, args=(火型, ))
    #rndrCode()
      #普切片=普欄[普欄位] #['Id', 'Path', 'Definition', 'Slice Name', 'Slicing Rules']
      #普切片#.T
    #if 單普:
    #  普欄=session_state['普欄']=普法[普法['Profile']==單普]
    #  普切片=普欄[['Id', 'Path', 'Definition', 'Slice Name', 'Slicing Rules']]
    #  普切片
    #  普法型=普欄[普欄['Type(s)'].str.contains('Backbone')]
