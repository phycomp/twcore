from 資源mnpl import 束資源
from stUtil import rndrCode
from fhirspec import FHIRStructureDefinition, FHIRStructureDefinitionElement
def rtrvSpec(fname):
  束RSRC = 束資源(fname)
  rndrCode('束RSRC', 束RSRC)
  resources = []
  for resource in 束RSRC:
    if "StructureDefinition" == resource["resourceType"]:
      resources.append(resource)
  for resource in resources:
    profile: FHIRStructureDefinition = FHIRStructureDefinition(spec, resource)
    #if self.found_profile(profile):
    profile.process_profile()
  differential = json_dict["differential"].get("element", [])

def 渲染(spec):
  rndrCode(['specWriteProfile', spec.writable_profiles()])
  for profile in spec.writable_profiles(): #除了 is_manual 都可以
    類別 = sorted(profile.writable_classes(), key=lambda x: x.name)
    if 0 == len(類別):
        if profile.url is not None:  # manual profiles have no url and usually write no 類別
          logger.info(f'Profile "{profile.url}" returns zero writable 類別, skipping')
        continue
    imports = profile.needed_external_classes()
    need_fhirtypes: bool = False
    has_one_of_many = False
    has_array_type = False
    has_required_primitive_element = False
    need_union_type = False
    need_typing = False
    need_root_validator = False
    need_pydantic_field = False
    one_of_many_fields = dict()
    required_primitive_element_fields = dict()
    for klass in 類別:
        for prop in klass.properties:
            if need_pydantic_field is False:
                need_pydantic_field = True
            # special variable
            prop.need_primitive_ext = False
            if (
                klass.name in ("Resource",)
                and spec.settings.CURRENT_RELEASE_NAME == "R4"
                and prop.class_name == "String"
                and prop.name == "id"
            ):
                # we force Resource.id type = Id
                prop.class_name = "Id"
                prop.field_type = "Id"
                prop.type_name = "id"

            if not prop.is_native and need_fhirtypes is False:
                need_fhirtypes = True
            if prop.is_array and has_array_type is False:
                has_array_type = True

            prop_klass = FHIRClass.with_name(prop.class_name)
            if prop_klass and prop_klass.class_type in (
                FHIR_CLASS_TYPES.resource,
                FHIR_CLASS_TYPES.logical,
                FHIR_CLASS_TYPES.complex_type,
            ):
                prop.field_type = prop.class_name + "Type"
            elif (
                prop_klass and prop_klass.class_type == FHIR_CLASS_TYPES.primitive_type
                or prop.is_native
            ) and prop.name != "id":
                prop.need_primitive_ext = True

            if prop_klass and prop_klass.class_type != FHIR_CLASS_TYPES.other:
                prop.field_type_module = "fhirtypes"

            # Check for Union Type
            if (
                prop.need_primitive_ext is True
                and prop.is_array
                and need_union_type is False
            ):
                need_union_type = True
            # check for one_of_many
            if prop.one_of_many:
                if has_one_of_many is False:
                    has_one_of_many = True
                if klass.name not in one_of_many_fields:
                    one_of_many_fields[klass.name] = {prop.one_of_many: []}
                if prop.one_of_many not in one_of_many_fields[klass.name]:
                    one_of_many_fields[klass.name][prop.one_of_many] = []
                one_of_many_fields[klass.name][prop.one_of_many].append(
                    prop.name
                )
            # Check Enums
            if prop.field_type == "Code" and prop.short and "|" in prop.short:
                prop.enum = enum_list = list()
                for item in map(lambda x: x.strip(), prop.short.split("|")):
                    parts = item.split(" ")
                    enum_list.append(parts[0])
                    if len(parts) == 2 and parts[1] == "+":
                        enum_list.append(parts[1])
            else:
                prop.enum = list()
            # check nooptional primitive element
            if (
                prop.need_primitive_ext
                and prop.nonoptional
                and not prop.one_of_many
                and klass.name != "Extension"
            ):
                if has_required_primitive_element is False:
                    has_required_primitive_element = True
                if klass.name not in required_primitive_element_fields:
                    required_primitive_element_fields[klass.name] = []
                required_primitive_element_fields[klass.name].append(
                    (prop.orig_name, prop.orig_name + "__ext")
                )

            # Fix Primitives Types
            if prop_klass and prop_klass.class_type == FHIR_CLASS_TYPES.primitive_type:
                if not prop.field_type.endswith("Type"):
                    prop.field_type += "Type"

    if has_one_of_many or has_required_primitive_element:
        need_root_validator = True

    if (
        need_union_type
        or has_one_of_many
        or has_required_primitive_element
        or has_array_type
    ):
        need_typing = True
    data = {
        "profile": profile,
        "release_name": spec.settings.CURRENT_RELEASE_NAME,
        "info": spec.info,
        "imports": imports,
        "classes": 類別,
        "need_fhirtypes": need_fhirtypes,
        "has_array_type": has_array_type,
        "fhir_class_types": FHIR_CLASS_TYPES,
        "one_of_many_fields": one_of_many_fields,
        "has_one_of_many": has_one_of_many,
        "need_union_type": need_union_type,
        "need_pydantic_field": need_pydantic_field,
        "need_typing": need_typing,
        "need_root_validator": need_root_validator,
        "required_primitive_element_fields": required_primitive_element_fields,
        "has_required_primitive_element": has_required_primitive_element,
    }
    ptrn = (
        profile.targetname.lower()
        if spec.settings.RESOURCE_MODULE_LOWERCASE
        else profile.targetname
    )
    source_path = spec.settings.RESOURCE_SOURCE_TEMPLATE
    target_name = spec.settings.RESOURCE_FILE_NAME_PATTERN.format(ptrn)
    target_path = spec.settings.RESOURCE_TARGET_DIRECTORY / target_name
    rndrCode(['data=', data.get('classes')[0].__dict__])#data.get('classes')[0].__dict__])
    spec.do_render(data, source_path, target_path)
def process_profile(spec) -> None:
  """Extract all elements and create 類別."""
  # or self.structure.snapshot
  struct = spec.structure.differential
  if struct is not None:
    mapped = {}
    for elem_dict in struct:
      element: FHIRStructureDefinitionElement=( FHIRStructureDefinitionElement(spec, elem_dict, spec.main_element is None)# noqa: E501
      )
      spec.elements.append(element)
      mapped[element.path] = element
      # establish hierarchy (may move to extra
      # loop in case elements are no longer in order)
      if element.is_main_profile_element:
          spec.main_element = element
      parent = mapped.get(element.parent_name)
      if parent:
          parent.add_child(element)

  # resolve element dependencies
  for element in spec.elements:
      element.resolve_dependencies()

  # run check: if n_min > 0 and parent is in summary, must also be in summary
  for element in spec.elements:
      if element.n_min is not None and element.n_min > 0:
          if element.parent is not None and element.parent.is_summary and not element.is_summary:
            LOGGER.error(f"n_min > 0 but not summary: `{element.path}`")#.format()
            element.summary_n_min_conflict = True

# create 類別 and class properties
  if spec.main_element is not None:
    snap_class, subs = spec.main_element.create_class()
    if snap_class is None:
        raise Exception(f'The main element for "{spec.url}" did not create a class')

    spec.found_class(snap_class)
    if subs is not None:
        for sub in subs:
            spec.found_class(sub)
    spec.targetname = snap_class.name
