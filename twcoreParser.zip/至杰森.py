from pandas import read_csv
from json import dumps as jsnDumps
import csv
import csv

def 至巢典(csv_file_path):
    nested_dict = {}
    with open(csv_file_path, 'r') as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            keys = row['key'].split('.')
            current_level = nested_dict
            for key in keys[:-1]:  # 遍历中间层
                if not isinstance(current_level.get(key), dict):
                    current_level[key] = {}
                current_level = current_level[key]
            current_level[keys[-1]] = row['value']  # 最后一层设置为值
    return nested_dict

# 使用示例
  csv_file_path = 'your_file.csv'  # 替换为你的CSV文件路径
  巢典 = 至巢典(csv_file_path)
  rndrCode(巢典)

def csv至杰森(file_path):
    # Attempt to detect delimiter
    with open(file_path, 'r', encoding='utf-8') as file:
      sample = file.read(1024)
      dialect = Sniffer().sniff(sample)
      delimiter = dialect.delimiter

    # Load CSV
    data = read_csv(file_path, sep=delimiter, encoding='utf-8')

    # Convert to JSON
    json_data = data.to_dict(orient='records')
    return json_data

# File path (update this with the actual file path)
file_path = '識別.csv'

# Convert and print JSON
data_json = csv至杰森(file_path)

# Pretty print JSON
rndrCode(jsnDumps(data_json, indent=4, ensure_ascii=False))
