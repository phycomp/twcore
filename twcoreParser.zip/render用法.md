self.do_render({"classes": all_classes}, "fhirtypesvalidators.jinja2", target_path
)
self.do_render("classes": all_classes,
"release_name": self.spec.settings.CURRENT_RELEASE_NAME,
self.do_render(data, source_path, target_path)
self.copy_files(target_path.parent)
# self.render_validators()
self.do_render( data, self.settings.DEPENDENCIES_SOURCE_TEMPLATE, self.settings.DEPENDENCIES_TARGET_FILE_NAME,
self.do_render(data, self.settings.CODE_SYSTEMS_SOURCE_TEMPLATE, target_path)
self.do_render(data, self.settings.UNITTEST_SOURCE_TEMPLATE, file_path)

