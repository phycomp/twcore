from typing import Tuple, Union, Sequence, Optional, Dict, Any, Iterable, List, defaultdict
from pathlib import Path
from pandas import read_csv

class 火規格:
    """The FHIR specification."""

    _finalized: bool

    def __init__(self, srcDrctry: Optional[Path]=None): #settings: Configuration,
        """
        :param src_directory:
        :param settings:

        self._finalized = False
        self.validate_settings(settings)
        self.definition_directory: pathlib.Path = typing.cast(pathlib.Path, getattr(settings, "FHIR_DEFINITION_DIRECTORY", None))
        self.example_directory: pathlib.Path = typing.cast(pathlib.Path, getattr(settings, "FHIR_EXAMPLE_DIRECTORY", None))
        version_info_file: pathlib.Path = typing.cast(pathlib.Path, getattr(settings, "FHIR_VERSION_INFO_FILE", None))
        if self.definition_directory is None or self.example_directory is None or version_info_file is None and src_directory is None:
            raise ValueError("src_directory is value is required!")
        if self.definition_directory is None:
            assert src_directory
            self.definition_directory = src_directory / "definitions"
        if self.example_directory is None:
            assert src_directory
            self.example_directory = src_directory / "examples"
        if version_info_file is None:
            assert src_directory
            version_info_file = src_directory / "version.info"

        self.settings = settings
        """
        #self.info: FHIRVersionInfo = FHIRVersionInfo(self, version_info_file)
        # system-url: FHIRValueSet()
        #self.valuesets: DefaultDict[str, FHIRValueSet] = defaultdict()
        # system-url: FHIRCodeSystem()
        #self.codesystems: DefaultDict[str, FHIRCodeSystem] = defaultdict()
        # profile-name: 結構定義()
        self.srcDrctry=srcDrctry
        self.profiles: DefaultDict[str, 結構定義] = defaultdict()
        # FHIRUnitTestCollection()
        #self.unit_tests: List[FHIRUnitTestCollection] = list()

        #self.prepare()
        self.read_profiles()
        #self.finalize()
    def read_profiles(self):
        self.fhirDF=read_csv(self.srcDrctry)
        #with open(self.srcDrctry) as fin:
        #  self.profile=jsnLoad(fin)

class 結構定義:
    """One FHIR structure definition."""

    def __init__(self, spec: 火規格, profile: Optional[Dict[str, Any]]):
        self.is_manual: bool = False
        # 結構定義Structure()
        self.structure: 結構定義Structure
        self.spec: 火規格 = spec
        self.url: Optional[str] = None
        self.targetname: Optional[str] = None
        # List of 結構定義Element
        self.elements: List[結構定義Element] = list()
        self.main_element: Optional[結構定義Element] = None
        # xxx: if ._class_map is required
        # self._class_map: Dict[str, str] = dict()
        self.classes: List[FHIRClass] = list()
        self._did_finalize: bool = False
        self.fhir_version: Optional[str] = None
        self.fhir_last_updated: Optional[str] = None
        self.elements_sequences: List[str] = list()

        if profile is not None:
            self.parse_profile(profile)

    @property
    def name(self) -> Union[str, None]:
        return self.structure.name if self.structure is not None else None

    def read_profile(self, filepath: Path) -> None:
        """Read the JSON definition of a profile from disk and parse.

        Not currently used.
        """
        with open(str(filepath), "r", encoding="utf-8") as handle:
            profile = json.load(handle)
        self.parse_profile(profile)

    def parse_profile(self, profDict: Dict[str, Any]) -> None:
        """Parse a JSON profile into a structure."""
        assert profDict
        assert "StructureDefinition" == profDict["resourceType"]

        # parse structure
        self.url = profDict.get("url")
        self.fhir_version = profDict.get("fhirVersion")
        self.fhir_last_updated = profDict.get("meta", {}).get("lastUpdated")
        LOGGER.info('Parsing profile "{}"'.format(profDict.get("name")))
        self.structure = 結構定義Structure(self, profDict)

    def process_profile(self) -> None:
        """Extract all elements and create classes."""
        # or self.structure.snapshot
        struct = self.structure.differential
        if struct is not None:
            mapped = {}
            for elem_dict in struct:

                element: 結構定義元素 = (
                    結構定義元素(self, elem_dict, self.main_element is None)
                )  # noqa: E501
                self.elements.append(element)
                mapped[element.path] = element

                # establish hierarchy (may move to extra
                # loop in case elements are no longer in order)
                if element.is_main_profile_element:
                    self.main_element = element
                parent = mapped.get(element.parent_name)
                if parent:
                    parent.add_child(element)

            # resolve element dependencies
            for element in self.elements:
                element.resolve_dependencies()

            # run check: if n_min > 0 and parent is in summary, must also be in summary
            for element in self.elements:
                if element.n_min is not None and element.n_min > 0:
                    if (
                        element.parent is not None
                        and element.parent.is_summary
                        and not element.is_summary
                    ):
                        LOGGER.error(
                            "n_min > 0 but not summary: `{}`".format(element.path)
                        )
                        element.summary_n_min_conflict = True

        # create classes and class properties
        if self.main_element is not None:
            snap_class, subs = self.main_element.create_class()
            if snap_class is None:
                raise Exception(
                    f'The main element for "{self.url}" did not create a class'
                )

            self.found_class(snap_class)
            if subs is not None:
                for sub in subs:
                    self.found_class(sub)
            self.targetname = snap_class.name

    def element_with_id(
        self, ident: str
    ) -> Union["結構定義Element", None]:
        """Returns a 結構定義ElementDefinition with the given
        id, if found. Used to retrieve elements defined via `contentReference`.
        """
        if self.elements:
            for element in self.elements:
                if element.definition and element.definition.id == ident:
                    return element
        return None

    # MARK: Class Handling
    def found_class(self, klass: "FHIRClass") -> None:
        self.classes.append(klass)

    def needed_external_classes(self) -> Iterable["FHIRClass"]:
        """Returns a unique list of class items that are needed for any of the
        receiver's classes' properties and are not defined in this profile.

        :raises: Will raise if called before `finalize` has been called.
        """
        if not self._did_finalize:
            raise Exception("Cannot use `needed_external_classes` before finalizing")

        internal = set([c.name for c in self.classes])
        needed = set()
        needs = []

        for klass in self.classes:
            # are there superclasses that we need to import?
            sup_cls = klass.superclass
            if (
                sup_cls is not None
                and sup_cls.name not in internal
                and sup_cls.name not in needed
            ):
                needed.add(sup_cls.name)
                needs.append(sup_cls)

            # look at all properties' classes and assign their modules
            for prop in klass.properties:
                prop_cls_name = prop.class_name
                assert isinstance(prop_cls_name, str)
                if (
                    prop_cls_name not in internal
                    and not self.spec.class_name_is_native(prop_cls_name)
                ):
                    prop_cls = FHIRClass.with_name(prop_cls_name)
                    if prop_cls is None:
                        raise Exception(
                            f'There is no class "{prop_cls_name}"'
                            f' for property "{prop.name}" on '
                            f'"{klass.name}" in {self.name}'
                        )
                    else:
                        prop.module_name = prop_cls.module
                        if prop_cls_name not in needed:
                            needed.add(prop_cls_name)
                            needs.append(prop_cls)

        return sorted(needs, key=lambda n: n.module or n.name)

    def referenced_classes(self) -> Iterable[str]:
        """Returns a unique list of **external** class names that are
        referenced from at least one of the receiver's `Reference`-type
        properties.

        :raises: Will raise if called before `finalize` has been called.
        """
        if not self._did_finalize:
            raise Exception("Cannot use `referenced_classes` before finalizing")

        references: Set[str] = set()
        for klass in self.classes:
            for prop in klass.properties:
                if len(prop.reference_to_names) > 0:
                    references.update(prop.reference_to_names)

        # no need to list references to our own classes, remove them
        for klass in self.classes:
            references.discard(klass.name)

        return sorted(references)

    def writable_classes(self) -> List["FHIRClass"]:
        classes = []
        for klass in self.classes:
            if klass.should_write():
                classes.append(klass)
        return classes

    # MARK: Finalizing
    def finalize(self) -> None:
        """Our spec object calls this when all profiles have been parsed."""

        # assign all super-classes as objects
        for cls in self.classes:
            if cls.superclass is None and cls.superclass_name is not None:
                super_cls = FHIRClass.with_name(cls.superclass_name)
                if super_cls is None and cls.superclass_name is not None:
                    raise Exception(
                        "There is no class implementation for class "
                        f'named "{cls.superclass_name}" in profile "{self.url}"'
                    )
                else:
                    cls.superclass = super_cls

        self._did_finalize = True

class 火元素型:
    """Representing a type of an element."""

    def __init__(self, type_dict: Optional[Dict[str, Any]] = None):
        self.code: str
        self.profile: Union[None, List[str]] = None

        if type_dict is not None:
            self.parse_from(type_dict)

    @staticmethod
    def parse_extension(type_dict: Dict[str, Any]) -> Union[Dict[str, Any], None]:
        """ """
        extensions = []
        urls = [
            "http://hl7.org/fhir/StructureDefinition/structuredefinition-fhir-type",
            "http://hl7.org/fhir/StructureDefinition/structuredefinition-json-type",
        ]

        if type_dict.get("_code", None) is not None:
            extensions = type_dict["_code"].get("extension", [])

        if len(extensions) == 0:
            # New Style from R4
            extensions = type_dict.get("extension", [])

        if len(extensions) > 0:

            extensions_ = [e for e in extensions if e.get("url") in urls]
            if len(extensions_) == 1:
                return extensions_[0]
            elif len(extensions_) > 1:
                raise Exception(
                    f"Found more than one structure definition JSON type in {type_dict}"
                )
        return None

    @staticmethod
    def parse_target_profile(type_dict: Dict[str, Any]) -> Union[List[str], None]:
        """ """
        profile = type_dict.get("targetProfile", None)
        if profile is None:
            return profile
        if isinstance(profile, (str, bytes)):
            profile = [profile]

        if not isinstance(profile, list):
            raise Exception(
                "Expecting a list for 'targetProfile' "
                "definition of an element type, got {0} as {1}".format(
                    profile, type(profile)
                )
            )
        return profile

    def parse_from(self, type_dict: Dict[str, Any]) -> None:
        """ """
        self.code = type_dict["code"]
        extension = 火元素型.parse_extension(type_dict)

        if self.code and HTTP_URL.match(self.code):
            if extension is None:
                raise NotImplementedError
            self.code = extension["valueUrl"]

        elif self.code is None:
            if extension is None:
                raise Exception(
                    'Expecting either "code" or "_code" and '
                    f"a JSON type extension, found neither in {type_dict}"
                )

            self.code = extension["valueString"]
        if self.code is None:
            raise Exception(f"No JSON type found in {type_dict}")

        if not isinstance(self.code, str):
            raise Exception(
                "Expecting a string for 'code' definition "
                f"of an element type, got {self.code} as {type(self.code)}"
            )
        profile = 火元素型.parse_target_profile(type_dict)
        if profile is not None:
            self.profile = profile
class 結構定義元素:
    """An element in a profile's structure."""

    def __init__(
        self,
        profile: 結構定義,
        element_dict: Dict[str, Any],
        is_main_profile_element: bool = False,
    ):
        assert isinstance(profile, 結構定義)
        self.profile: 結構定義 = profile
        self.path: Optional[str] = None
        self.parent: Optional[結構定義元素] = None
        self.children: Optional[List[結構定義元素]] = None
        self.parent_name: Optional[str] = None
        self.definition: Optional[結構定義元素定義] = None
        self.n_min: Optional[int] = None
        self.n_max: Optional[str] = None
        self.is_summary: bool = False
        # to mark conflicts,
        # see #13215 (http://gforge.hl7.org/gf/project/fhir/tracker/
        # ?action=TrackerItemEdit&tracker_item_id=13125)
        self.summary_n_min_conflict: bool = False
        self.valueset: Optional[FHIRValueSet] = None
        # assigned if the element has a binding
        # to a ValueSet that is a CodeSystem generating an enum
        self.enum: Optional[Dict[str, Any]] = None
        self.is_main_profile_element: bool = is_main_profile_element
        self.represents_class: bool = False

        self._superclass_name: Optional[str] = None
        self._did_resolve_dependencies: bool = False

        if element_dict: self.parse_from(element_dict)# is not None
        else: self.definition = 結構定義元素定義(self, None)

    def parse_from(self, element_dict: Dict[str, Any]) -> None:
        """
        :param element_dict:
        :return:
        """
        self.path = element_dict["path"]
        assert isinstance(self.path, str)
        parts = self.path.split(".")
        self.parent_name = ".".join(parts[:-1]) if len(parts) > 0 else None
        prop_name = parts[-1]
        if "-" in prop_name:
            prop_name = "".join([n[:1].upper() + n[1:] for n in prop_name.split("-")])

        self.definition = 結構定義元素定義(self, element_dict)
        self.definition.prop_name = prop_name

        self.n_min = element_dict.get("min")
        self.n_max = element_dict.get("max")
        self.is_summary = element_dict.get("isSummary", False)

    def resolve_dependencies(self) -> None:
        if self.is_main_profile_element: self.represents_class = True
        if not self.represents_class and self.children is not None and len(self.children) > 0: self.represents_class = True
        if self.definition is not None:
            self.definition.resolve_dependencies()

        self._did_resolve_dependencies = True

    # MARK: Hierarchy

    def add_child(self, element: "結構定義元素") -> None:
        """
        :param element:
        :return:
        """
        element.parent = self
        if self.children is None: self.children = [element]
        else:
            self.children.append(element)

    def create_class(self, module: Optional[str] = None) -> Tuple[Union["FHIRClass", None], Union[None, Sequence["FHIRClass"]]]:
        """Creates a FHIRClass instance from the receiver, returning the
        created class as the first and all inline defined subclasses as the
        second item in the tuple.
        """
        assert self._did_resolve_dependencies
        if not self.represents_class:
            return None, None

        class_name = self.name_if_class()  # noqa: F841
        subs = []
        cls, did_create = FHIRClass.for_element(self)
        children = self.children or []
        if did_create:
            LOGGER.debug(f'Created class "{cls.name}"')
            if module is None and self.is_main_profile_element:
                module = self.profile.spec.as_module_name(cls.name)
            cls.module = module
            for child in children:
                cls.add_property_in_sequence(child)

        for child in children: # child classes
            properties = child.as_properties()
            if properties is not None:
                sub, subsubs = child.create_class(module) # collect subclasses
                if sub is not None: subs.append(sub)
                if subsubs is not None: subs.extend(subsubs)

                # add properties to class
                if did_create:
                    for prop in properties: cls.add_property(prop)

        return cls, subs

    def as_properties(self) -> Union[List["FHIRClassProperty"], None]:
        """If the element describes a *class property*, returns a list of
        FHIRClassProperty instances, None otherwise.
        """
        assert self._did_resolve_dependencies
        if self.is_main_profile_element or self.definition is None:
            return None

        # TODO: handle slicing information (not sure why these properties were
        # omitted previously)
        # if self.definition.slicing:
        #    logger.debug('Omitting property "{}"
        #    for slicing'.format(self.definition.prop_name))
        #    return None

        # this must be a property
        if self.parent is None:
            raise Exception(f'Element reports as property but has no parent: "{self.path}"')
        # create a list of FHIRClassProperty instances (usually with only 1 item)
        if len(self.definition.types) > 0:
            props: List[FHIRClassProperty] = []
            for type_obj in self.definition.types:
                # an inline class
                if "BackboneElement" == type_obj.code or "Element" == type_obj.code:  # data types don't use "BackboneElement"
                    propKlss=FHIRClassProperty(self, type_obj, self.name_if_class())
                    props.append(propKlss)
                    # TODO: look at http://hl7.org/fhir/
                    # StructureDefinition/structuredefinition-explicit-type-name ?
                else:
                    props.append(FHIRClassProperty(self, type_obj, None))
            return props

        # no `type` definition in the element:
        # it's a property with an inline class definition
        type_obj = 火元素型()
        return [FHIRClassProperty(self, type_obj, self.name_if_class())]

    # MARK: Name Utils
    def name_of_resource(self) -> str:
        assert self._did_resolve_dependencies
        if not self.is_main_profile_element:
            return self.name_if_class()
        name = self.definition and self.definition.name or self.path
        assert isinstance(name, str)
        return name

    def name_if_class(self) -> str:
        assert self.definition
        name = self.definition.name_if_class()
        assert isinstance(name, str)
        return name

    @property
    def superclass_name(self) -> Optional[str]:
        """Determine the superclass for the element (used for class elements)."""
        if self._superclass_name is None:
            assert self.definition
            tps = self.definition.types
            if len(tps) > 1:
                raise Exception(
                    "Have more than one type to determine superclass "
                    f'in "{self.path}": "{tps}"'
                )
            type_code: Optional[str] = None

            if self.is_main_profile_element and self.profile.structure.subclass_of is not None: type_code = self.profile.structure.subclass_of
            elif len(tps) > 0: type_code = tps[0].code
            elif self.profile.structure.kind: type_code = self.profile.spec.settings.DEFAULT_BASES.get(self.profile.structure.kind)
            if type_code is not None: self._superclass_name = self.profile.spec.class_name_for_type(type_code)

        return self._superclass_name

class 結構定義元素定義:
    """The definition of a FHIR element."""

    def __init__(self, element: 結構定義元素, definition_dict: Optional[Dict[str, Any]] = None):
        self.id: Optional[str] = None
        self.element: 結構定義元素 = element
        self.types: List[火元素型] = []
        self.name: Optional[str] = None
        self.prop_name: Optional[str] = None
        self.content_reference: Optional[str] = None
        self._content_referenced: Optional[結構定義元素定義]=None
        self.short: Optional[str] = None
        self.formal: Optional[str] = None
        self.comment: Optional[str] = None
        self.binding: Optional[FHIRElementBinding] = None
        self.constraint: Optional[FHIRElementConstraint] = None
        self.mapping: Optional[FHIRElementMapping] = None
        self.slicing: Optional[Dict[str, Any]] = None
        self.representation: Optional[Sequence[str]] = None
        # TODO: handle  "slicing"

        if definition_dict is not None:
            self.parse_from(definition_dict)

    def parse_from(self, definition_dict: Dict[str, Any]) -> None:
        self.id = definition_dict.get("id")
        self.types = []
        for type_dict in definition_dict.get("type", []):
            self.types.append(火元素型(type_dict))

        self.name = definition_dict.get("name")
        self.content_reference = definition_dict.get("contentReference")

        self.short = definition_dict.get("short")
        self.formal = definition_dict.get("definition")
        if self.formal and self.short == self.formal[:-1]: self.formal = None # formal adds a trailing period
        self.comment = definition_dict.get("comments")

        if "binding" in definition_dict:
            self.binding = FHIRElementBinding(definition_dict["binding"])
        if "constraint" in definition_dict:
            self.constraint = FHIRElementConstraint(definition_dict["constraint"])
        if "mapping" in definition_dict:
            self.mapping = FHIRElementMapping(definition_dict["mapping"])
        if "slicing" in definition_dict:
            self.slicing = definition_dict["slicing"]
        self.representation = definition_dict.get("representation")

class FHIRClassProperty:
    """An element describing an instance property."""

    def __init__(self, element: 結構定義元素, type_obj: 火元素型, type_name: Optional[str] = None,):
        assert element and type_obj
        # and must be instances of 結構定義元素 and 火元素型
        spec = element.profile.spec

        self.path = element.path
        # assign if this property has been expanded from "property[x]"
        self.one_of_many: Optional[str] = None

        if not type_name: type_name = type_obj.code
        self.type_name = type_name

        name = element.definition and element.definition.prop_name or None
        assert isinstance(name, str)
        if "[x]" in name:
            self.one_of_many = name.replace("[x]", "")
            name = name.replace(
                "[x]", "{0}{1}".format(type_name[:1].upper(), type_name[1:])
            )
        self.orig_name: str = name
        self.name: str = spec.safe_property_name(name)
        self.parent_name: Optional[str] = element.parent_name
        self.class_name: Optional[str] = spec.class_name_for_type_if_property(type_name)
        self.enum = element.enum if "code" == type_name else None
        # should only be set if it's an external module (think Python)
        self.module_name: Optional[str] = None
        assert isinstance(self.class_name, str)
        self.json_class: str = spec.json_class_for_class_name(self.class_name)
        self.is_native: bool = (
            False if self.enum else spec.class_name_is_native(self.class_name)
        )
        self.is_array: bool = True if "*" == element.n_max else False
        self.is_summary: bool = element.is_summary
        self.is_summary_n_min_conflict: bool = element.summary_n_min_conflict
        self.nonoptional: bool = (
            True if element.n_min is not None and 0 != int(element.n_min) else False
        )
        self.reference_to_names: List[str] = list()
        if type_obj.profile:
            names = spec.class_name_for_profile(type_obj.profile)
            if isinstance(names, str):
                self.reference_to_names.append(names)
            elif isinstance(names, list):
                self.reference_to_names = names

        if element.definition:
            self.short: Optional[str] = element.definition.short
            self.formal: Optional[str] = element.definition.formal
            self.representation: Optional[
                Sequence[str]
            ] = element.definition.representation

        self.field_type = self.class_name
        self.field_type_module = self.module_name

class FhirProfile:
    """An element in a profile's structure."""

    def __init__(self, profile: 結構定義, element_dict: Dict[str, Any], is_main_profile_element: bool=False):
        assert isinstance(profile, 結構定義)
        self.profile: 結構定義 = profile
        self.path: Optional[str] = None
        self.parent: Optional[結構定義元素] = None
        self.children: Optional[List[結構定義元素]] = None
        self.parent_name: Optional[str] = None
        self.definition: Optional[結構定義元素定義] = None
        self.n_min: Optional[int] = None
        self.n_max: Optional[str] = None
        self.is_summary: bool = False
        # to mark conflicts,
        # see #13215 (http://gforge.hl7.org/gf/project/fhir/tracker/
        # ?action=TrackerItemEdit&tracker_item_id=13125)
        self.summary_n_min_conflict: bool = False
        self.valueset: Optional[FHIRValueSet] = None
        # assigned if the element has a binding
        # to a ValueSet that is a CodeSystem generating an enum
        self.enum: Optional[Dict[str, Any]] = None
        self.is_main_profile_element: bool = is_main_profile_element
        self.represents_class: bool = False

        self._superclass_name: Optional[str] = None
        self._did_resolve_dependencies: bool = False

        if element_dict is not None:
            self.parse_from(element_dict)
        else:
            self.definition = 結構定義元素定義(self, None)

    def parse_from(self, element_dict: Dict[str, Any]) -> None:
        """
        :param element_dict:
        :return:
        """
        self.path = element_dict["path"]
        assert isinstance(self.path, str)
        parts = self.path.split(".")
        self.parent_name = ".".join(parts[:-1]) if len(parts) > 0 else None
        prop_name = parts[-1]
        if "-" in prop_name:
            prop_name = "".join([n[:1].upper() + n[1:] for n in prop_name.split("-")])

        self.definition = 結構定義元素定義(self, element_dict)
        self.definition.prop_name = prop_name

        self.n_min = element_dict.get("min")
        self.n_max = element_dict.get("max")
        self.is_summary = element_dict.get("isSummary", False)

    def resolve_dependencies(self) -> None:
        if self.is_main_profile_element: self.represents_class = True
        if not self.represents_class and self.children is not None and len(self.children) > 0: self.represents_class = True
        if self.definition is not None:
            self.definition.resolve_dependencies()

        self._did_resolve_dependencies = True

    # MARK: Hierarchy

    def add_child(self, element: "結構定義元素") -> None:
        """
        :param element:
        :return:
        """
        element.parent = self
        if self.children is None: self.children = [element]
        else:
            self.children.append(element)

    def create_class(
        self, module: Optional[str] = None
    ) -> Tuple[Union["FHIRClass", None], Union[None, Sequence["FHIRClass"]]]:
        """Creates a FHIRClass instance from the receiver, returning the
        created class as the first and all inline defined subclasses as the
        second item in the tuple.
        """
        assert self._did_resolve_dependencies
        if not self.represents_class:
            return None, None

        class_name = self.name_if_class()  # noqa: F841
        subs = []
        cls, did_create = FHIRClass.for_element(self)
        children = self.children or []
        if did_create:
            LOGGER.debug(f'Created class "{cls.name}"')
            if module is None and self.is_main_profile_element:
                module = self.profile.spec.as_module_name(cls.name)
            cls.module = module
            for child in children:
                cls.add_property_in_sequence(child)

        # child classes
        for child in children:
            properties = child.as_properties()
            if properties is not None:

                # collect subclasses
                sub, subsubs = child.create_class(module)
                if sub is not None:
                    subs.append(sub)
                if subsubs is not None:
                    subs.extend(subsubs)

                # add properties to class
                if did_create:
                    for prop in properties:
                        cls.add_property(prop)

        return cls, subs

    def as_properties(self) -> Union[List["FHIRClassProperty"], None]:
        """If the element describes a *class property*, returns a list of
        FHIRClassProperty instances, None otherwise.
        """
        assert self._did_resolve_dependencies
        if self.is_main_profile_element or self.definition is None:
            return None

        # TODO: handle slicing information (not sure why these properties were
        # omitted previously)
        # if self.definition.slicing:
        #    logger.debug('Omitting property "{}"
        #    for slicing'.format(self.definition.prop_name))
        #    return None

        # this must be a property
        if self.parent is None:
            raise Exception(
                f'Element reports as property but has no parent: "{self.path}"'
            )

        # create a list of FHIRClassProperty instances (usually with only 1 item)
        if len(self.definition.types) > 0:
            props: List[FHIRClassProperty] = []
            for type_obj in self.definition.types:
                # an inline class
                if "BackboneElement" == type_obj.code or "Element" == type_obj.code:  # data types don't use "BackboneElement"
                    klss=FHIRClassProperty(self, type_obj, self.name_if_class())
                    props.append(klss)
                    # TODO: look at http://hl7.org/fhir/
                    # StructureDefinition/structuredefinition-explicit-type-name ?
                else:
                    props.append(FHIRClassProperty(self, type_obj, None))
            return props

        # no `type` definition in the element:
        # it's a property with an inline class definition
        type_obj = 火元素型()
        return [FHIRClassProperty(self, type_obj, self.name_if_class())]

    # MARK: Name Utils
    def name_of_resource(self) -> str:
        assert self._did_resolve_dependencies
        if not self.is_main_profile_element:
            return self.name_if_class()
        name = self.definition and self.definition.name or self.path
        assert isinstance(name, str)
        return name

    def name_if_class(self) -> str:
        assert self.definition
        name = self.definition.name_if_class()
        assert isinstance(name, str)
        return name

    @property
    def superclass_name(self) -> Optional[str]:
        """Determine the superclass for the element (used for class elements)."""
        if self._superclass_name is None:
            assert self.definition
            tps = self.definition.types
            if len(tps) > 1:
                raise Exception(
                    "Have more than one type to determine superclass "
                    f'in "{self.path}": "{tps}"'
                )
            type_code: Optional[str] = None

            if self.is_main_profile_element and self.profile.structure.subclass_of is not None: type_code = self.profile.structure.subclass_of
            elif len(tps) > 0: type_code = tps[0].code
            elif self.profile.structure.kind: type_code = self.profile.spec.settings.DEFAULT_BASES.get(self.profile.structure.kind)
            if type_code is not None: self._superclass_name = self.profile.spec.class_name_for_type(type_code)

        return self._superclass_name



