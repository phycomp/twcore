class {主元素}({主型}):
  resource_type = Field("{主元素}", const=True)

  @classmethod
  def elements_sequence(cls):
    return {元素序列}
