from pydantic import Field, root_validator
from pydantic.error_wrappers import ErrorWrapper, ValidationError
from pydantic.errors import MissingError, NoneIsNotAllowedError

from fhirtypes import {全型}
from typing import List, Dict
from backbone import BackboneElement
from domainresource import DomainResource

