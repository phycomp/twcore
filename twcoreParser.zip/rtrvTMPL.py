from jinja2 import Environment, PackageLoader, TemplateNotFound
from jinja2 import pass_context as contextfilter    #filters, utils
from stUtil import rndrCode
from streamlit import info as stInfo

jinjaenv = Environment(loader=PackageLoader("generate", 'templates'))  #self.settings.TEMPLATE_DIRECTORY

@contextfilter
def string_wrap(ctx, value, width=88, to_json=True):
    """ """

    def simple_wrap(v):
        return f'"{v}"'

    def htmlsafe_json_dumps(v):
        rv = json.dumps(v)
        return Markup(rv)

    if not value:
        return value
    if to_json is True:
        dumper = htmlsafe_json_dumps
    else:
        dumper = simple_wrap

    wrapper = TextWrapper(
        width=width, replace_whitespace=True, drop_whitespace=False, tabsize=4
    )
    new_value = map(lambda x: dumper(x), wrapper.wrap(value))
    return list(new_value)
def rtrvTMPL(template_name, data=None):
  #rndrCode(['jinjaenv', jinjaenv.__dict__.keys()])
  template = jinjaenv.get_template(template_name)
  rndrCode(['template_name', template_name, template.__dict__])
  rendered = template.render(data)
  stInfo(rendered)
  #rndrCode(['rendered', rendered])

