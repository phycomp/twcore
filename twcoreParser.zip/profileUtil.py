from stUtil import rndrCode
from streamlit import session_state

def 找bckBone(普DF):
  普DF['找到'] = 普DF['Path'].where(普DF['Type(s)'].str.match('BackboneElement|null'))#普欄[][普欄['Path']]# # > 0, 普欄['one'].values
  return 普DF['Path'][普DF['找到'].notnull().values].values

def 聚集(ele, 骨典):
  if '骨型' not in session_state:
    session_state['骨型']=0
  else:
    if 骨典.match(ele):
      session_state['骨型']+=1
    #else:
    #  session_state['骨型']=0
  return session_state['骨型']
