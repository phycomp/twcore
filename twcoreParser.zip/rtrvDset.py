from fhirspec import FHIRSpec, Configuration
from fhirspec import FHIRStructureDefinitionStructure
from pathlib import Path
from typing import Dict, Any
from json import load as jsnLoad
#FHIRSpec
import config
from stUtil import rndrCode
from fhirloader import FHIRLoader
cache_path='twcore'

def 設定規格():
  settings = Configuration.from_module(config)
  #rndrCode(['settings', settings.as_dict()])
  loader = FHIRLoader(settings, settings.BASE_PATH / cache_path / settings.CURRENT_RELEASE_NAME)
  #force_download, cache_only=False, False
  specSRC = loader.load(force_download=False, force_cache=True)
  return settings, specSRC
  rndrCode(['specSRC', specSRC]) #PosixPath('/data/JOSH/GITs/fhir-parser/twcore/R5')
def 讀規格(filepath: Path) -> None:
  with open(str(filepath), encoding="utf-8") as handle:
      profile = jsnLoad(handle)
  profDict = {"differential": {"element": [{"path": ''}]}, "name": 'demo'}
  return FHIRStructureDefinitionStructure(profile, profDict)
  #structure = FHIRStructureDefinitionStructure(profile, profDict)
  #return url, fhir_version, fhir_last_updated, structure

def 得結構(profile, profDict: Dict[str, Any]) -> None: #parse_profile
  """Parse a JSON profile into a structure."""
  assert profile
  #rndrCode(['profile=', profile])
  assert "StructureDefinition" == profDict["resourceType"]

  # parse structure
  url = profDict.get("url")
  fhir_version = profDict.get("fhirVersion")
  fhir_last_updated = profDict.get("meta", {}).get("lastUpdated")
  #LOGGER.info('Parsing profile "{}"'.format(profile.get("name")))
  #profDict = {"differential": {"element": [{"path": ''}]}, "name": 'demo'}
  structure = FHIRStructureDefinitionStructure(profile, profDict)
  #FHIRStructureDefinition(spec, profile)
  #def __init__(self, spec: FHIRSpec, profile: Optional[Dict[str, Any]]):
  return url, fhir_version, fhir_last_updated, structure

def 運行元素(spec) -> None: #process_profile
  """Extract all elements and create classes."""
  # or self.structure.snapshot
  struct = spec.structure.differential
  if struct is not None:
    mapped = {}
    for elem_dict in struct:

        element: FHIRStructureDefinitionElement = ( FHIRStructureDefinitionElement(spec, elem_dict, spec.main_element is None))# noqa: E501
        spec.elements.append(element)
        mapped[element.path] = element

        # establish hierarchy (may move to extra
        # loop in case elements are no longer in order)
        if element.is_main_profile_element:
            spec.main_element = element
        parent = mapped.get(element.parent_name)
        if parent:
            parent.add_child(element)

    # resolve element dependencies
    for element in spec.elements:
        element.resolve_dependencies()

    # run check: if n_min > 0 and parent is in summary, must also be in summary
    for element in spec.elements:
        if element.n_min is not None and element.n_min > 0:
            if (
                element.parent is not None
                and element.parent.is_summary
                and not element.is_summary
            ):
                LOGGER.error(
                    "n_min > 0 but not summary: `{}`".format(element.path)
                )
                element.summary_n_min_conflict = True

  # create classes and class properties
  if spec.main_element is not None:
      snap_class, subs = spec.main_element.create_class()
      if snap_class is None:
          raise Exception(
              f'The main element for "{spec.url}" did not create a class'
          )

      spec.found_class(snap_class)
      if subs is not None:
          for sub in subs:
              spec.found_class(sub)
      spec.targetname = snap_class.name
def read_profile(filepath: Path) -> None:
  """Read the JSON definition of a profile from disk and parse.

  Not currently used.
  """
  with open(str(filepath), "r", encoding="utf-8") as handle:
    profile = jsnLoad(handle)
  spec.parse_profile(profile)
