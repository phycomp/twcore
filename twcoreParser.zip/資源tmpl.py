  {tmpl元素}: {型} = Field(None,
    alias="{tmpl元素}",
    element_property=True
  )

